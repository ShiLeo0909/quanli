package oop4;

public class PrimeFactors {
    public static void main(String[] args) {
        int n = 20;
    }
    public static boolean checkPrime(int number){
        for (int i = 1; i < (int) Math.sqrt(number); i++) {
            if(number % i == 0){
                return false;
            }
        }
        return true;
    }
    public static void PerfectPrimeFactorList(int n){
        for (int i = 0; i < n; i++) {
            if(
        }
    }
}
