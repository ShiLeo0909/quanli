package oop4;

public class RecursiveBinarySearch {
}
