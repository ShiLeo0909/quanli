package oop8.EX4_3;

public class CountryArrayManager {
    private Country [] countries;
    private int length;
    public int increment;

    public CountryArrayManager(){
        countries = new Country[1];
        this.length = 0;
    }
    public CountryArrayManager(int maxLength ){
        countries = new Country[maxLength];
        this.length=0;
    }

}
