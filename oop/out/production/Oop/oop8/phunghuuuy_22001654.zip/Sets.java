package oop8;

import java.util.*;

public class Sets {
    // Kiem tra phan tu giong nhau roi cho vao mang moi
    public static Set<Integer> intersectionManual(Set<Integer>first,
                                                  Set<Integer> second){
        Set<Integer> newSet = new HashSet<>();
        for (Integer i : first) {
            if(second.contains(i)){
                newSet.add(i);
            }
        }
        return newSet;
    }
    public static Set<Integer> unionManual(Set<Integer> first , Set<Integer> second){
        Set<Integer> newSet = new HashSet<>();
        for (Integer i : first) {
            newSet.add(i);
        }
        for (Integer i : second) {
            if(!first.contains(i)){
                newSet.add(i);
            }
        }
        return newSet;
    }
    public static Set<Integer > union(Set<Integer> first , Set<Integer> second){
        Set<Integer> newSet = new HashSet<>(first);
        newSet.addAll(second);
        return newSet;
    }
    public static Set<Integer> intersection(Set<Integer> first , Set<Integer> second){
        Set<Integer> newSet = new HashSet<>(first);
            newSet.retainAll(second);
        return newSet;
    }
    public static List<Integer> toList(Set<Integer> source){
        List<Integer> list = new ArrayList<>(source);
        return list;
    }
    public static String firstRecurringCharacter(String s) {
        char[] ch = s.toCharArray();
        for (int i = 0; i < ch.length - 1; i++) {
            for (int j = 1; j < ch.length; j++) {
                if (ch[i] == ch[j]) {
                    return ch[i] + " ";
                }
            }
        }
        return "Ko co phan tu nao trung nhau";
    }

    public static Set<Character> allRecurringChars(String s) {
        char[] ch = s.toCharArray();
        Set<Character> source = new HashSet<>();
        for (int i = 0; i < ch.length - 1; i++) {
            for (int j = 1; j < ch.length; j++) {
                if (ch[i] == ch[j]) {
                    source.add(s.charAt(i));
                }
            }
        }
        return source;
    }

    public static Integer[] toArray(Set<Integer> source) {
        Integer[] arr = new Integer[source.size()];
        source.toArray(arr);
        return arr;
    }
    public static int getFirst(TreeSet<Integer> source){
        return source.first();
    }
    public static int getLast(TreeSet<Integer> source ){
        return source.last();
    }
    public static int getGreater(TreeSet<Integer> source , int value){
        return source.higher(5);
    }

    public static void main(String[] args) {
        Set<Integer> first = new HashSet<>(Arrays.asList(1,2,3,4,5));
        Set<Integer> second = new HashSet<>(Arrays.asList(1,2,3,4,6));
        System.out.println(intersectionManual(first , second));
        System.out.println(intersection(first , second));
        System.out.println(unionManual(first , second));
        System.out.println(union(first , second));
        System.out.println(toList(first));
    }
}
