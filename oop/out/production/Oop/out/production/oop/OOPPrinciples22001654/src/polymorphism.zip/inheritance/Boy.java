package inheritance;

public class Boy extends Father {
    private String name;

    public Boy(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
