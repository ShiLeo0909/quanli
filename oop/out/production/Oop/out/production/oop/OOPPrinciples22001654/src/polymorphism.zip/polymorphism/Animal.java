package polymorphism;

public class Animal {
    void sound (){
        System.out.println("Âm thanh động vật");
    }
}
