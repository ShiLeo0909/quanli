package polymorphism;

public class Cat extends Animal{
    void sound(){
        System.out.println("Meo Meo");
    }
}
