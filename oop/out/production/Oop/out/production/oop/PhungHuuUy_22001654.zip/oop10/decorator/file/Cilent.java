package oop10.decorator.file;

public class Cilent {
    public static void main(String[] args) {

    }
}
