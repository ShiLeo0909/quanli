package oop10.decorator.icecream;

public class ChocolateIceCream implements IceCream{
    @Override
    public String getDescription() {
        return "Chocolate";
    }
}
