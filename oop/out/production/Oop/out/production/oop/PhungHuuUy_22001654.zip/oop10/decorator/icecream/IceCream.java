package oop10.decorator.icecream;

public interface IceCream {
    String getDescription();
}
