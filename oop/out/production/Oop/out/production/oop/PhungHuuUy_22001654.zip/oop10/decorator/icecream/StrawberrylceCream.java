package oop10.decorator.icecream;

public class StrawberrylceCream implements IceCream{
    @Override
    public String getDescription() {
        return "Strawberr";
    }
}
