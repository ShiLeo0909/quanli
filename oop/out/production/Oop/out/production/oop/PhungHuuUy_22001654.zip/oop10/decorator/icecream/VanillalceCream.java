package oop10.decorator.icecream;

public class VanillalceCream implements IceCream{
    @Override
    public String getDescription() {
        return "VanillalcaCream";
    }
}
