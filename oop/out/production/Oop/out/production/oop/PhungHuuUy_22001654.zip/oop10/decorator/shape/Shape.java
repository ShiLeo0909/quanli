package oop10.decorator.shape;

public interface Shape {
    void draw();
}
