package oop10.observer;

public abstract class Observer {
    public Subject subject;
    public abstract void update();
}
