package oop10.strategy.pseudocode;

public interface Strategy {
    int Calculate(int a , int b);
}
