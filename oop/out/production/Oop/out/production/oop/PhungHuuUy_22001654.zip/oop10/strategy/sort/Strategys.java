package oop10.strategy.sort;

public interface Strategys {
    void sort(int [] array);
}
