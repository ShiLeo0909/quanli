package oop11.bridge.ex;

public interface OperatingSystem {
    void startup();

    void loadUrl(String url);

}
