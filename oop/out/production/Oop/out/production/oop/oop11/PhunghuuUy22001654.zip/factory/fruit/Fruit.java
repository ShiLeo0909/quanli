package oop11.factory.fruit;

public interface Fruit {
    public void produceJuice();
}
