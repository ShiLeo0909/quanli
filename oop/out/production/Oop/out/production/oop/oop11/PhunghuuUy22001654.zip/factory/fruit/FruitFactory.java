package oop11.factory.fruit;

public interface FruitFactory {
    public Fruit provideFruit(String type);
}
