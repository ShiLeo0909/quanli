import java.util.Scanner;

public class Dec2Hex {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter a decimal number");
//        String str = sc.nextLine();
        String decStr = readInfo(sc);

        if (checkDecimalNumber(decStr)) {
            System.out.println("The equivalent hexadecimal number is: " + dec2Hex(decStr));
        } else {
            System.out.println("Invalid number !");
        }
    }

    public static String readInfo (Scanner sc) {
        System.out.printf("Enter a decimal number: ");
        String decStr = sc.nextLine();
        return decStr;
    }

    public static boolean checkDecimalNumber (String decStr) {
        for (int decChar = 0; decChar < decStr.length(); decChar++) {
            if (!(decStr.charAt(decChar) >= '0' && decStr.charAt(decChar) <= '9')) {
                return false;
            }
        }
        return true;
    }

    public static String dec2Hex (String decStr) {
        Integer decNum = Integer.parseInt(decStr);
        String hexStr = "0123456789ABCDEF";
        char num = 0;
        String result = "";
        while  (decNum > 0) {
            num = hexStr.charAt(decNum % 16);
            decNum /= 16;
            result = num + result;
        }
        return result;
    }
}
//        if(HexNumber(str)){
//            calculateHex2Dec(str);
//        }else{
//            System.out.println(str + "The equivalen not  hexdecim al number is");
//        }
//    }
//    public static boolean HexNumber( String str) {
//            for (int i = 0; i < str.length(); i++) {
//                if (str.charAt(i) <= '0' && str.charAt(i) >= '9' || str.charAt(i) <= 'a' && str.charAt(i) >= '9') {
//                    return false;
//                } else {
//                    return true;
//                }
//            }
//        return true;
//    }
//    public static double calculateHex2Dec( String str) {
//        String hex = "0123456789abcdef";
//        String inStrtoLowerCase = str.toLowerCase();
//        int sum = 0;
//        for (int i = 0; i < str.length(); i++) {
//            sum = sum * 16 + hex.indexOf(inStrtoLowerCase.charAt(i));
//        }
//        return sum;
//    }
//}
