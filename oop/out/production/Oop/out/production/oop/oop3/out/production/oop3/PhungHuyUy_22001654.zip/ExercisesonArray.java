import java.util.Scanner;

public class ExercisesonArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of items :");
        int NUM_ITEMS = sc.nextInt();
        printExercisesonArray(NUM_ITEMS ,sc);
    }
    public static void printExercisesonArray(int  NUM_ITEMS  , Scanner sc){
        int [] list = new int [ NUM_ITEMS ];
        System.out.println("Enter the value of all items ( separated by space ) :");
        for (int i = 0; i < list.length ; i++) {
            list[i] = sc.nextInt();
        }
        System.out.print("The values are : ");
        for (int i = 0; i < list.length; i++) {
            System.out.print(list[i] + " ");
        }
    }
}
