

public class ExercisesonMethod {
    public static void main(String[] args) {

    }

    public static int expoent(int base, int exp) {
        int product = 1;
        for (int i = 0; i < exp; i++) {
            product *= base;
        }
        return product;
    }


    public static boolean hasEight(int number) {
        int surplus = 0;
        while (number > 0) {
            surplus = number % 10;
            if (surplus == 8) {
                return true;
            }
            number /= 10;
        }
        return false;
    }

    public static String arraytoString(int[] array) {
        if (array == null) return null;
        StringBuilder arrayString = new StringBuilder("[");
        for (int i = 0; i < array.length - 1; i++) {
            arrayString.append(array[i])
                    .append(",");
        }
        arrayString.append(array[array.length - 1])
                .append("]");
        return arrayString.toString();
    }

    public static void print(int[] array) {
        System.out.print("[ ");
        for (int element : array) {
            System.out.println(element + "");
        }
        System.out.println(" ]");
    }

    public static boolean contains(int[] array, int key) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == key) {
                return true;
            }
        }
        return true;
    }

    public static int search(double[] array, double value) {
        for (int i = 0; i < array.length; i++) {
            if ((Double.compare(array[i], value)) == 0) {
                return i;
            }
        }
        return -1;
    }


    public static boolean equals(int[] left, int[] right) {
        if (left.length != right.length) {
            return false;
        }
        boolean ok = true;
        for (int i = 0; i < left.length; i++) {
            if (left[i] != right[i]) {
                ok = false;
            }
        }
        return ok;
    }

    public static int[] copyOf(int[] array) {
        int[] copiesArray = new int[array.length];
        for (int i = 0; i < array.length; i++) {
            copiesArray[i] = array[i];
        }
        return copiesArray;
    }

    public static void reverse(int[] array) {
        for (int i = 0; i < array.length / 2; i++) {
            int temp = array[i];
            array[i] = array[array.length - 1 - i];
            array[array.length - 1 - i] = temp;
        }
    }

    public static int[] reverseTo(int[] array) {
        int[] reveredArray = copyOf(array);
        reverse(reveredArray);
        return reveredArray;
    }

    public static boolean swap(int[] array1, int[] array2) {
        if (array1.length != array2.length) {
            return false;
        }
        for (int i = 0; i < array1.length; i++) {
            int temp = array1[i];
            array1[i] = array2[i];
            array2[i] = temp;
        }
        return true;
    }
}

