import java.util.Scanner;

public class GradesStatistics {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of students in the class :");
        int numberStudent = sc.nextInt();
        int[] student = new int[numberStudent];
        for (int i = 0; i < student.length; i++) {
            student[i] = sc.nextInt();
        }

        printGradesStatistics(student);
        System.out.println("The average is :" + calculateAverage(student));
        highestPoint(student);
        shortPoint(student);
    }

    public static void printGradesStatistics(int[] student) {
        for (int i = 0; i < student.length; i++) {
            System.out.println("Student's Score : " + i + "= " + student[i]);
        }
    }

    public static double calculateAverage(int[] student) {
        int sum = 0;
        for (int i = 0; i < student.length; i++) {
             sum += student[i];
        }
        return sum / student.length;
    }

    public static void highestPoint(int[] student) {
        int highestPoint = student[0];
        for (int i = 0; i < student.length - 1; i++) {
            if (highestPoint > student[i + 1]) {
                highestPoint = student[i + 1];
            }
        }
        System.out.println("The minimum is :" + highestPoint);
    }

    public static void shortPoint(int[] student) {
        int shortPoint = student[0];
        for (int i = 0; i < student.length - 1; i++) {
            if (shortPoint < student[i + 1]) {
                shortPoint = student[i + 1];
            }
        }
        System.out.println("The maxsimum is :" + shortPoint);
    }


}
