import java.util.Scanner;

public class GradesStatisticss {
    public static int [] grades;
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        System.out.print("Enter the number of students :");
        int student = in.nextInt();
        int[] grades = new int[student];
        readGrades(in,grades,student);
        print(grades,student);
        System.out.println("The average is :" + averageGradeOfStudent(grades));
        System.out.println("The minimum is :" +  minGradeOfStudent(grades));
        System.out.println("The maximum is :" + maxGradeOfStudent(grades));
        System.out.println("The median is : " + median(grades));
        System.out.println("The standard deviation is :" + stdDev(grades) );
    }
    public static void readGrades(Scanner in ,int[] grades, int student) {
        for (int i = 0; i < student; i++){
            System.out.print("Enter the grade for student " + (i+1) + ": ");
            grades[i] = in.nextInt();
        }
    }
    public static void print(int [] grades,int student){
        System.out.print("The grades are : [ ");
        for (int i = 0; i < student; i++) {
            System.out.print(grades[i] + " ");
        }
        System.out.println("]");
    }
    public static double averageGradeOfStudent (int[] grades) {
        int sum  = 0;
        for (int i = 0; i < grades.length; i++){
            sum += grades[i];
        }
        double average  = sum / grades.length;
        return (double) average;
    }
    public static double median(int[] grades) {
        int temp;
        for(int i = 0; i < grades.length; i++){
            for (int j = i + 1; j < grades.length ; j++) {
                if (grades[i] < grades[j]){
                    temp = grades[i];
                    grades[i] = grades[j];
                    grades[j] = temp;
                }
            }
        }
        double median = 0;
        if ((grades.length + 1) % 2 == 0) {
            median = ( grades[grades.length / 2] + grades[grades.length / 2 -1])/2;
        } else {
            median = grades[grades.length / 2];
        }
        return median;
    }
    public static int maxGradeOfStudent(int[] grades){
        int max = grades[0];
        for (int i = 0; i < grades.length; i++){
            if (max < grades[i]){
                max = grades[i];
            }
        }
        return max;
    }
    public static int minGradeOfStudent(int[] grades) {
        int min = grades[0];
        for (int i = 0; i < grades.length; i++) {
            if (min > grades[i]){
                min = grades[i];
            }
        }
        return min;
    }
    public static double stdDev(int [] grades){
        double sum = 0;
        double average = averageGradeOfStudent(grades);
        for (int i = 0 ; i < grades.length ; i++) {
            sum += Math.pow(Math.abs(grades[i] - average),2) ;
        }
        return (double) Math.sqrt(sum/4);
    }
}