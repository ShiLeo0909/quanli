
import java.util.Scanner;

public class Hex2Bin {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String hexStr = readInfo(sc);
        String hexStrToLowerCase = hexStr.toLowerCase();

        if (checkHexadecimalString(hexStrToLowerCase)) {
            hexToBin(hexStr);
        } else {
            System.out.println("Invalid hexadecimal string !");
        }
    }

    public static String readInfo(Scanner sc) {
        System.out.printf("Enter the Hexadecimal string: ");
        String hexStr = sc.nextLine();
        return hexStr;
    }

    public static boolean checkHexadecimalString(String hexStr) {
        for (int hexChar = 0; hexChar < hexStr.length(); hexChar++) {
            if (!(hexStr.charAt(hexChar) >= '0' && hexStr.charAt(hexChar) <= '9'
                    || hexStr.charAt(hexChar) >= 'a' && hexStr.charAt(hexChar) <= 'f')) {
                return false;
            }
        }
        return true;
    }

    public static void hexToBin(String hexStr) {
        System.out.printf("The equivalent binary for hexadecimal " + hexStr + " is: ");
        String[] hex_bits = {"0000", "0001", "0010", "0011", "0100", "0101", "0110",
                "0111", "1000", "1001", "1010", "1011", "1100", "1101",
                "1110", "1111"};
        String result;
        String hex_Strings = "0123456789abcdef";
        for (int hexChar = 0; hexChar < hexStr.length(); hexChar++) {
            result = hex_bits[hex_Strings.indexOf(hexStr.charAt(hexChar))];
            System.out.printf(result + " ");
        }
    }
}

