import java.util.Scanner;

public class PrintArrayInStars {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of items :");
        int item = sc.nextInt();
        printArrayInStars( item, sc);
    }

    public static void printArrayInStars(int item, Scanner sc) {
        System.out.println("Enter the value of all items ( separated by space ) :");
        int list[] = new int[item];
        for (int i = 0; i < list.length; i++) {
            list[i] = sc.nextInt();
        }
        for (int i = 0; i < list.length; i++) {
            System.out.print(i + ":");
            for (int j = 0; j < list[i]; j++) {
                System.out.print("*");
            }
            System.out.println("(" + list[i] + ")");
        }
    }
}

