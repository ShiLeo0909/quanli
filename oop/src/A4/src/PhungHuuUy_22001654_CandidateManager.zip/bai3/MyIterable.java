package bai3;

public interface MyIterable {
    MyIterator iterator();
}
