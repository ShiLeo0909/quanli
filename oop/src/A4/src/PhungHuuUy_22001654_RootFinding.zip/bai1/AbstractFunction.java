package bai1;

public interface AbstractFunction {
    double evaluate(double x);

}
