package bai1;

public class UnivariateRealFunction implements AbstractFunction {
    @Override
    public double evaluate(double x) {
        /* TODO */
        return    x * Math.sin(x) - 3;

    }
}
