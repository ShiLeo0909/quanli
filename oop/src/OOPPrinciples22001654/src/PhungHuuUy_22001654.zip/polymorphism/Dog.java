package polymorphism;

public class Dog extends Animal {
    void sound(){
        System.out.println("Gow Gow");
    }
}
