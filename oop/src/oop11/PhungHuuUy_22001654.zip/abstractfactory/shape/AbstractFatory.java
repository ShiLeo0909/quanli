package oop11.abstractfactory.shape;

public  interface  AbstractFatory {
    public Shape getShape(String type);
}
