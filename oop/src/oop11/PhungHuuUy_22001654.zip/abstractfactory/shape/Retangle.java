package oop11.abstractfactory.shape;

public class Retangle implements Shape  {
    @Override
    public void draw() {
        System.out.println("Bố cân hết");
    }
}
