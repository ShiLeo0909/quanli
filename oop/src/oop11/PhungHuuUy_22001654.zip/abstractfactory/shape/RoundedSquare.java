package oop11.abstractfactory.shape;

public class RoundedSquare implements Shape{
    @Override
    public void draw() {

    }
}
