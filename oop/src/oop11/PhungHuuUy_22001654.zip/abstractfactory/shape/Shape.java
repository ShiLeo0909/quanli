package oop11.abstractfactory.shape;

public interface Shape {
    public void draw();
}
