package oop11.abstractfactory.shape;

public class Square implements Shape{
    @Override
    public void draw() {

    }
}
