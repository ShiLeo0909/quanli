package oop11.command.computer;

public interface Command {
    void execute();
}
