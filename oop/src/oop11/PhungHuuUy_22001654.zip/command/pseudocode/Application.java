package oop11.command.pseudocode;

public class Application {
    Editor[] editors;

}
