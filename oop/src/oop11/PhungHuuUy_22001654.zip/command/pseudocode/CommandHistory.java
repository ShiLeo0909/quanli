package oop11.command.pseudocode;

public class CommandHistory {
    private Command [] history;

    public CommandHistory(Command[] history) {
        this.history = history;
    }
    public void push(Command c){

    }
    public Command pop(){
        return null;
    }
}
