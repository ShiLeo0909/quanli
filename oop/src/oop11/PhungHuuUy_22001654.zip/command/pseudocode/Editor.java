package oop11.command.pseudocode;

public class Editor {
    public void getSelection(){

    }
    public void deleteSelection(){

    }
    public void replaceSelection(){

    }
}
