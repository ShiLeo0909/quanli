package oop11.factory.fruit;

public class Apple implements Fruit{
    @Override
    public void produceJuice() {
        System.out.println("Fruit Apple");
    }
}
