package oop11.factory.fruit;

public class Banana implements Fruit{
    @Override
    public void produceJuice() {
        System.out.println("Fruit Banana");
    }
}
