package oop11.iterrator;

public interface Iterable {
    Iterator getIterator();
}
