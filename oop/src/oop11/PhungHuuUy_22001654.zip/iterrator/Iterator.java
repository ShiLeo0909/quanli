package oop11.iterrator;

public interface Iterator {
    boolean hasNext();
    Object nex();
}
