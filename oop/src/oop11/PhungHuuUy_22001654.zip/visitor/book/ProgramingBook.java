package oop11.visitor.book;

public interface ProgramingBook  extends Book{
    String getResource();
}
