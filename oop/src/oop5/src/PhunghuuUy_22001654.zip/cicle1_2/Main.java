package cicle1_2;
public class Main {
    public static void main(String[] args) {
        Circle c = new Circle();
        System.out.println(c.getArea());
        System.out.println(c.getRadius());
        System.out.println(c.getCircumference());
        System.out.println(c.toString());
    }
}