package cutomer2_5;

public class TestMain {
}
