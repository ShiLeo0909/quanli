package rectangle1_3;

public class TestRectangle {
    public static void main(String[] args) {
        Rectangle r = new Rectangle();
        System.out.println(r.getArea());
        System.out.println(r.getLength());
        System.out.println(r.getWidth());
        System.out.println(r.getPerimeter());
        System.out.println(r.toString());
    }
}
