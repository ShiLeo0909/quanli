package OPP2;

public class BaseSystem {
    public static void main(String[] args) {

    }
}
