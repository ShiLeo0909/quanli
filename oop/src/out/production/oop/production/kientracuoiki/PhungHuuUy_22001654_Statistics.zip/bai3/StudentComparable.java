package bai3;

public interface StudentComparable {
    int compareTo(Student another);
}
