package bai3;

public interface StudentComparator {
    int compare(Student left, Student right);
}

