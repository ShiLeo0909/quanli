package bai3;

import java.util.ArrayList;
import java.util.Collections;

public class StudentStatistics {
    private MyList students;

    /**
     * Khởi tạo dữ liệu cho StudentManager.
     */
    public StudentStatistics(MyList data) {
        /* TODO */
        this.students = data;
    }

    /**
     * Lấy ra danh sách các sinh viên được sắp xếp theo thứ tự phụ thuộc vào tên và họ.
     * Chú ý, không thay đổi thứ tự sinh viên trong danh sách gốc.
     * @param order
     * @return danh sách các sinh viên đã được sắp xếp
     */
    public MyList sortByFullname(boolean order) {
        /*
         TODO

         - Sửa lại lớp Student để sử dụng MyComparable để thực hiện việc so sánh các Student theo tên và họ.
           Thứ tự đầu tiên phụ thuộc vào tên, nếu tên bằng nhau thì thứ tự phụ thuộc vào họ.

         - Sử dụng tiêu chí so sánh trong MyComparable, viết code để sắp xếp danh sách các sinh viên theo thứ tự
           phụ thuộc tham số order. Nếu order là true thì sắp xệp theo thứ tự tăng dần. Nếu order là false thì
           sắp xếp theo thứ tự giảm dần.

         - Trả ra danh sách sinh viên mới đã được sắp thứ tự.
         */

    }

    /**
     * Lấy ra danh sách các sinh viên được sắp xếp theo average.
     * Chú ý, không thay đổi thứ tự sinh viên trong danh sách gốc.
     * @param order
     * @return
     */
//
    public MyList sortByAverage(boolean order) {
        // Sort by average using AverageComparison
        Collections.sort(students, new AverageComparison());

        if (!order) {
            // Reverse the list if order is false
            Collections.reverse(students);
        }

        return students;
    }

    private class AverageComparison implements StudentComparator<Student> {
        @Override
        public int compare(Student s1, Student s2) {
            // Compare by average
            int averageComparison = Double.compare(s1.getAverage(), s2.getAverage());
            return order ? averageComparison : -averageComparison;
        }
    }
}
