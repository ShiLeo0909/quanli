package bai3;

import java.util.Iterator;

public class TestMyList {
    public static void main(String[] args) {
        /*
         TODO

         - Chạy demo các hàm test.
         - Lưu kết quả chạy chương trình vào file text có tên <Ten_MaSinhVien_MyList>.txt
           (ví dụ, NguyenVanA_123456_MyList.txt)
         - Nộp kết quả chạy chương trình (file text trên) cùng với các file source code.
         */
        testMyArrayList();
        testMyLinkedList();
    }

    public static void testMyArrayList() {
        /*
         TODO

         - Tạo ra một list kiểu MyArrayList có ít nhất 10 Student.

         - Sử dụng StudentStatistics để
             + Sắp xếp và in ra danh sách các Student theo thứ tự tăng dần theo tên và họ.
             + Sắp xếp và in ra danh sách các Student theo thứ tự giảm dần theo tên và họ.
             + Sắp xếp và in ra danh sách các Student theo thứ tự tăng dần về average.
             + Sắp xếp và in ra danh sách các Student theo thứ tự giảm dần về average.
         */
        System.out.println("Test ArrayList");
        MyArrayList myArrayList = new MyArrayList();
        myArrayList.append(9.9);
        myArrayList.append(8.8);
        myArrayList.append(6.6);
        myArrayList.append(5.5);
        myArrayList.append(4.4);
        myArrayList.append(3.3);
        myArrayList.append(2.2);
        System.out.println(myArrayList);
        myArrayList.insert(7.7, 2);
        System.out.println(myArrayList);
        myArrayList.set(3.3, 2);
        System.out.println(myArrayList);
        myArrayList.remove(0);
        System.out.println(myArrayList);


    }

    public static void testMyLinkedList() {
        /*
         TODO

         - Tạo ra một list kiểu MyLinkedList có ít nhất 10 Student.

         - Sử dụng StudentStatistics để
             + Sắp xếp và in ra danh sách các Student theo thứ tự tăng dần theo tên và họ.
             + Sắp xếp và in ra danh sách các Student theo thứ tự giảm dần theo tên và họ.
             + Sắp xếp và in ra danh sách các Student theo thứ tự tăng dần về average.
             + Sắp xếp và in ra danh sách các Student theo thứ tự giảm dần về average.
         */
        System.out.println("Test LinkedList");
        MyLinkedList myLinkedList = new MyLinkedList();
        myLinkedList.append(9.9);
        myLinkedList.append(8.8);
        myLinkedList.append(6.6);
        myLinkedList.append(5.5);
        myLinkedList.append(4.4);
        myLinkedList.append(3.3);
        myLinkedList.append(2.2);
        System.out.println(myLinkedList);
        myLinkedList.insert(7.7, 2);
        System.out.println(myLinkedList);
        myLinkedList.set(3.3, 2);
        myLinkedList.remove(0);
        System.out.println(myLinkedList);
    }

    public static void testIterator(MyList myList) {
        /*
         TODO
         Sử dụng iterator duyệt qua tất cả các phần tử trong danh sách myList và in ra thông tin về phần tử đó.
         */
    }
}
